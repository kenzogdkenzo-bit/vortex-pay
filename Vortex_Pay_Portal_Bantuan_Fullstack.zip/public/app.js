const $ = (id) => document.getElementById(id);
const authView = $("authView");
const appView = $("appView");
const message = $("message");
let authMode = "login";
let currentUser = null;

function showMessage(text, kind = "") {
  message.textContent = text;
  message.className = "status" + (kind ? " " + kind : "");
  message.classList.remove("hidden");
  message.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function clearMessage() { message.classList.add("hidden"); message.textContent = ""; }
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Permintaan gagal. Coba lagi.");
  return data;
}
function setAuthMode(mode) {
  authMode = mode;
  $("loginTab").classList.toggle("active", mode === "login");
  $("registerTab").classList.toggle("active", mode === "register");
  $("nameField").classList.toggle("hidden", mode !== "register");
  $("authSubmit").textContent = mode === "login" ? "Login" : "Buat akun";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("password").minLength = mode === "login" ? 1 : 10;
  clearMessage();
}
$("loginTab").addEventListener("click", () => setAuthMode("login"));
$("registerTab").addEventListener("click", () => setAuthMode("register"));

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = $("authSubmit");
  button.disabled = true;
  try {
    const body = {
      name: $("name").value.trim(),
      email: $("email").value.trim(),
      password: $("password").value
    };
    const result = await api(`/api/auth/${authMode === "login" ? "login" : "register"}`, {
      method: "POST", body: JSON.stringify(body)
    });
    currentUser = result.user;
    $("password").value = "";
    await showDashboard();
    showMessage(authMode === "login" ? "Login berhasil." : "Akun berhasil dibuat.", "success");
  } catch (error) { showMessage(error.message, "error"); }
  finally { button.disabled = false; }
});

async function showDashboard() {
  authView.classList.add("hidden");
  appView.classList.remove("hidden");
  $("logoutBtn").classList.remove("hidden");
  $("welcome").textContent = `Halo, ${currentUser.name}`;
  await loadHistory();
}
async function loadHistory() {
  try {
    const data = await api("/api/tickets");
    const list = $("ticketList");
    list.replaceChildren();
    if (!data.tickets.length) {
      const empty = document.createElement("div"); empty.className = "empty"; empty.textContent = "Belum ada tiket. Pengajuan yang kamu buat akan tampil di sini."; list.appendChild(empty);
    } else {
      data.tickets.forEach(ticket => {
        const item = document.createElement("div"); item.className = "ticket";
        const title = document.createElement("div"); title.className = "ticket-title"; title.textContent = `#${ticket.id} · ${ticket.subject}`;
        const meta = document.createElement("div"); meta.className = "ticket-meta"; meta.textContent = `${ticket.category} · ${formatDate(ticket.created_at)}`;
        const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = ticket.status;
        const details = document.createElement("p"); details.className = "muted"; details.textContent = ticket.message;
        item.append(title, meta, tag, details); list.appendChild(item);
      });
    }
    const activities = $("activityList");
    activities.replaceChildren();
    if (!data.activities.length) activities.textContent = "Belum ada aktivitas.";
    else data.activities.forEach(activity => {
      const line = document.createElement("div"); line.className = "ticket";
      const event = document.createElement("div"); event.className = "ticket-title"; event.textContent = activity.event;
      const date = document.createElement("div"); date.className = "ticket-meta"; date.textContent = formatDate(activity.created_at);
      line.append(event, date); activities.appendChild(line);
    });
  } catch (error) {
    if (error.message.includes("login")) {
      currentUser = null; appView.classList.add("hidden"); authView.classList.remove("hidden"); $("logoutBtn").classList.add("hidden");
    }
    showMessage(error.message, "error");
  }
}
function formatDate(value) {
  if (!value) return "Waktu tidak tersedia";
  const d = new Date(value.replace(" ", "T") + (value.includes("Z") ? "" : "Z"));
  return Number.isNaN(d.getTime()) ? value : d.toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });
}
$("ticketForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = $("ticketSubmit"); button.disabled = true;
  try {
    const result = await api("/api/tickets", {
      method: "POST",
      body: JSON.stringify({
        category: $("category").value,
        subject: $("subject").value.trim(),
        message: $("ticketMessage").value.trim()
      })
    });
    $("ticketForm").reset();
    await loadHistory();
    showMessage(`Pengajuan #${result.ticket.id} berhasil disimpan di portal. Ini bukan nomor tiket resmi DANA.`, "success");
  } catch (error) { showMessage(error.message, "error"); }
  finally { button.disabled = false; }
});
$("logoutBtn").addEventListener("click", async () => {
  $("logoutBtn").disabled = true;
  try { await api("/api/auth/logout", { method: "POST", body: "{}" }); }
  catch (error) { showMessage(error.message, "error"); }
  currentUser = null;
  appView.classList.add("hidden"); authView.classList.remove("hidden"); $("logoutBtn").classList.add("hidden");
  $("authForm").reset(); setAuthMode("login"); showMessage("Kamu sudah keluar.", "success");
  $("logoutBtn").disabled = false;
});
(async function init() {
  try {
    const data = await api("/api/auth/me");
    currentUser = data.user;
    await showDashboard();
  } catch (_) {
    authView.classList.remove("hidden");
    appView.classList.add("hidden");
  }
})();
