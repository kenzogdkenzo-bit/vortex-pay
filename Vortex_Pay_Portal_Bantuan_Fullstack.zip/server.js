require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET || "";

if (isProduction && sessionSecret.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters in production.");
  process.exit(1);
}
if (!isProduction && !process.env.SESSION_SECRET) {
  console.warn("Development only: set SESSION_SECRET in .env before deployment.");
}

const dbPath = path.resolve(process.env.DB_PATH || "./data/vortex.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    category TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Diajukan',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    event TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_tickets_user_created ON tickets(user_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_activities_user_created ON activities(user_id, created_at DESC);
`);

const SQLiteStore = SQLiteStoreFactory(session);
const sessionStore = new SQLiteStore({
  db: "sessions.sqlite",
  dir: path.dirname(dbPath),
  table: "sessions"
});

app.disable("x-powered-by");
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  name: "vortex.sid",
  secret: sessionSecret || "local-development-secret-change-before-deploy",
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });
const ticketLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });

app.use((req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method) && req.headers.origin) {
    const origin = req.headers.origin;
    const host = req.headers.host;
    let parsed;
    try { parsed = new URL(origin); } catch { return res.status(403).json({ error: "Origin tidak valid." }); }
    if (parsed.host !== host) return res.status(403).json({ error: "Permintaan lintas situs ditolak." });
  }
  next();
});

const findUser = db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?");
const addActivity = db.prepare("INSERT INTO activities (user_id, event) VALUES (?, ?)");
function publicUser(row) {
  return row ? { id: row.id, name: row.name, email: row.email, createdAt: row.created_at } : null;
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Silakan login terlebih dahulu." });
  const user = findUser.get(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: "Sesi tidak berlaku. Silakan login kembali." });
  }
  req.user = user;
  next();
}
function cleanString(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

app.get("/api/health", (req, res) => res.json({ ok: true, service: "vortex-pay-support", time: new Date().toISOString() }));

app.post("/api/auth/register", authLimiter, async (req, res, next) => {
  try {
    const name = cleanString(req.body.name, 70);
    const email = cleanString(req.body.email, 254).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";
    if (name.length < 2) return res.status(400).json({ error: "Nama minimal 2 karakter." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Format email tidak valid." });
    if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Password harus 10–128 karakter." });
    const passwordHash = await bcrypt.hash(password, 12);
    let result;
    try {
      result = db.prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)").run(name, email, passwordHash);
    } catch (err) {
      if (String(err.code).includes("CONSTRAINT")) return res.status(409).json({ error: "Email sudah terdaftar." });
      throw err;
    }
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = Number(result.lastInsertRowid);
      addActivity.run(req.session.userId, "Akun dibuat");
      res.status(201).json({ user: publicUser(findUser.get(req.session.userId)) });
    });
  } catch (err) { next(err); }
});

app.post("/api/auth/login", authLimiter, async (req, res, next) => {
  try {
    const email = cleanString(req.body.email, 254).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";
    const row = db.prepare("SELECT * FROM users WHERE email = ? COLLATE NOCASE").get(email);
    const valid = row && await bcrypt.compare(password, row.password_hash);
    if (!valid) return res.status(401).json({ error: "Email atau password salah." });
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = row.id;
      addActivity.run(row.id, "Login berhasil");
      res.json({ user: publicUser(findUser.get(row.id)) });
    });
  } catch (err) { next(err); }
});

app.post("/api/auth/logout", (req, res, next) => {
  const userId = req.session.userId;
  if (userId) addActivity.run(userId, "Logout");
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("vortex.sid", { httpOnly: true, sameSite: "lax", secure: isProduction });
    res.json({ ok: true });
  });
});

app.get("/api/auth/me", requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

app.get("/api/tickets", requireAuth, (req, res) => {
  const tickets = db.prepare(`
    SELECT id, category, subject, message, status, created_at, updated_at
    FROM tickets WHERE user_id = ? ORDER BY id DESC LIMIT 100
  `).all(req.user.id);
  const activities = db.prepare(`
    SELECT event, created_at FROM activities WHERE user_id = ? ORDER BY id DESC LIMIT 30
  `).all(req.user.id);
  res.json({ tickets, activities });
});

app.post("/api/tickets", requireAuth, ticketLimiter, (req, res) => {
  const category = cleanString(req.body.category, 60);
  const subject = cleanString(req.body.subject, 120);
  const message = cleanString(req.body.message, 3000);
  const allowed = ["Kendala upgrade", "Verifikasi akun", "Transaksi", "Aplikasi", "Lainnya"];
  if (!allowed.includes(category)) return res.status(400).json({ error: "Kategori tidak valid." });
  if (subject.length < 5) return res.status(400).json({ error: "Judul minimal 5 karakter." });
  if (message.length < 20) return res.status(400).json({ error: "Pesan minimal 20 karakter." });
  const result = db.prepare("INSERT INTO tickets (user_id, category, subject, message) VALUES (?, ?, ?, ?)").run(req.user.id, category, subject, message);
  addActivity.run(req.user.id, `Tiket #${result.lastInsertRowid} dibuat`);
  const ticket = db.prepare("SELECT id, category, subject, message, status, created_at, updated_at FROM tickets WHERE id = ? AND user_id = ?").get(result.lastInsertRowid, req.user.id);
  res.status(201).json({ ticket });
});

app.get("/api/tickets/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "ID tiket tidak valid." });
  const ticket = db.prepare("SELECT id, category, subject, message, status, created_at, updated_at FROM tickets WHERE id = ? AND user_id = ?").get(id, req.user.id);
  if (!ticket) return res.status(404).json({ error: "Tiket tidak ditemukan." });
  res.json({ ticket });
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Terjadi kesalahan server. Coba lagi nanti." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Vortex Pay Support portal listening on port ${PORT}`);
});
