# Vortex Pay — Portal Bantuan Independen

Portal ini menyediakan akun pengguna, riwayat tiket bantuan, dan pengajuan kendala upgrade. Portal **bukan aplikasi resmi DANA** dan tidak dapat mengubah status DANA Premium. Pengguna diarahkan ke kanal resmi untuk penyelesaian akun atau verifikasi.

## Keamanan dan batasan
- Jangan meminta/menyimpan PIN, password DANA, OTP, foto KTP, atau selfie.
- Jangan menyatakan tiket portal ini sebagai tiket resmi DANA.
- Untuk bantuan akun DANA, arahkan pengguna ke `https://www.dana.id/help-center`.
- Password portal di-hash dengan bcrypt; sesi disimpan di SQLite.
- Database perlu penyimpanan persisten pada hosting. `render.yaml` menggunakan disk persisten pada Render Starter.
- Ini adalah dasar aplikasi yang berjalan, bukan sertifikasi keamanan atau integrasi DANA. Uji sebelum dibuka ke publik.

## Jalankan di komputer
1. Pasang Node.js 20+.
2. Salin `.env.example` menjadi `.env`.
3. Isi `SESSION_SECRET` dengan string acak panjang (minimal 32 karakter).
4. Jalankan `npm install`, lalu `npm start`.
5. Buka `http://localhost:3000`.

## Deploy ke Render
1. Unggah folder ini ke repositori GitHub (jangan unggah `.env`).
2. Di Render pilih **New → Blueprint** dan pilih repositori tersebut.
3. Blueprint memakai disk persisten; paket `starter` berbayar. Pastikan biaya dan konfigurasi aktual di Render sebelum deploy.
4. Setelah deploy, uji pendaftaran, login, membuat tiket, keluar, dan login kembali.
5. Domain HTTPS disediakan oleh Render. Simpan `SESSION_SECRET` dengan aman dan lakukan backup database berkala.

## API
- `GET /api/health`
- `POST /api/auth/register` `{ "name": "...", "email": "...", "password": "..." }`
- `POST /api/auth/login` `{ "email": "...", "password": "..." }`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/tickets`
- `POST /api/tickets` `{ "category": "...", "subject": "...", "message": "..." }`
- `GET /api/tickets/:id`

Session cookie HttpOnly, SameSite=Lax; mutating requests check same-origin when an Origin header is present. Rate limits apply to authentication and ticket creation.
